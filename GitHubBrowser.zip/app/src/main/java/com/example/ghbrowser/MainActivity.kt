package com.example.ghbrowser

import android.app.*
import android.content.*
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*

class MainActivity : Activity() {
    private val g = "https://github.com"
    private val desk = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val shortcuts = listOf(
        "🏠 Home" to g, "🔥 Trending" to "$g/trending", "🧭 Explore" to "$g/explore",
        "🐛 Issues" to "$g/issues", "🔀 PRs" to "$g/pulls", "🔔 Alerts" to "$g/notifications",
        "⭐ Stars" to "$g/stars", "📝 Gists" to "https://gist.github.com",
        "☁️ Codespaces" to "$g/codespaces", "⚙️ Settings" to "$g/settings/profile"
    )
    private val tabs = mutableListOf<WebView>()
    private var cur = 0
    private var desktop = false
    private var darkGh = true
    private var picker: ValueCallback<Array<Uri>>? = null
    private lateinit var holder: FrameLayout
    private lateinit var addr: EditText
    private lateinit var bar: ProgressBar
    private lateinit var tabBtn: TextView
    private lateinit var prefs: SharedPreferences
    private val bg = Color.parseColor("#0d1117")
    private val sf = Color.parseColor("#161b22")
    private val fg = Color.parseColor("#e6edf3")
    private val ac = Color.parseColor("#58a6ff")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tab() = tabs[cur]
    private fun pill(c: Int, r: Int) = GradientDrawable().apply { setColor(c); setCornerRadius(dp(r).toFloat()) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("gh", 0)
        window.statusBarColor = bg
        window.navigationBarColor = sf
        addr = EditText(this).apply {
            setSingleLine(); hint = "Search GitHub or owner/repo"
            setTextColor(fg); setHintTextColor(Color.GRAY); textSize = 15f
            background = pill(sf, 24); setPadding(dp(18), 0, dp(18), 0)
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> go(text.toString()); true }
            setOnFocusChangeListener { _, f -> if (f) selectAll() }
        }
        val chips = LinearLayout(this).apply { setPadding(dp(8), dp(2), dp(8), dp(6)) }
        shortcuts.forEach { (n, u) ->
            chips.addView(TextView(this).apply {
                text = n; setTextColor(fg); textSize = 13f
                setPadding(dp(14), dp(7), dp(14), dp(7)); background = pill(sf, 16)
                setOnClickListener { load(u) }
            }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(ac); visibility = View.GONE
        }
        holder = FrameLayout(this)
        tabBtn = btn("▢ 1") { tabList() }
        val bottom = LinearLayout(this).apply {
            setBackgroundColor(sf)
            addView(btn("‹") { if (tab().canGoBack()) tab().goBack() })
            addView(btn("›") { if (tab().canGoForward()) tab().goForward() })
            addView(btn("⟳") { tab().reload() })
            addView(tabBtn)
            addView(btn("⋮") { menu() })
        }
        val top = FrameLayout(this).apply {
            setPadding(dp(10), dp(8), dp(10), dp(6))
            addView(addr, FrameLayout.LayoutParams(-1, dp(46)))
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(bg)
            addView(top, LinearLayout.LayoutParams(-1, -2))
            addView(bar, LinearLayout.LayoutParams(-1, dp(2)))
            addView(scroll, LinearLayout.LayoutParams(-1, -2))
            addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(bottom, LinearLayout.LayoutParams(-1, dp(54)))
        })
        newTab(intent?.data?.toString() ?: g)
    }

    private fun btn(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 20f; setTextColor(fg); gravity = Gravity.CENTER
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
    }

    private fun newTab(url: String) {
        val w = WebView(this)
        w.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            builtInZoomControls = true; displayZoomControls = false
            useWideViewPort = true; loadWithOverviewMode = true
            if (desktop) userAgentString = desk
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        w.setBackgroundColor(bg)
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.scheme == "http" || u.scheme == "https") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) {}
                return true
            }
            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) {
                if (v === tab()) { addr.setText(u); bar.visibility = View.VISIBLE }
            }
            override fun onPageCommitVisible(v: WebView, u: String) = dark(v)
            override fun onPageFinished(v: WebView, u: String) {
                dark(v)
                if (v === tab()) bar.visibility = View.GONE
                add("hist", v.title, u)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { if (v === tab()) bar.progress = p }
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: WebChromeClient.FileChooserParams): Boolean {
                picker?.onReceiveValue(null); picker = cb
                try { startActivityForResult(p.createIntent(), 1) } catch (e: Exception) { picker = null; return false }
                return true
            }
        }
        w.setDownloadListener { u, ua, cd, mt, _ ->
            val r = DownloadManager.Request(Uri.parse(u))
            r.setMimeType(mt)
            r.addRequestHeader("User-Agent", ua)
            r.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(u) ?: "")
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(u, cd, mt))
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            toast("Downloading…")
        }
        tabs.add(w); select(tabs.size - 1); w.loadUrl(url)
    }

    private fun dark(v: WebView) {
        if (darkGh) v.evaluateJavascript("document.documentElement.setAttribute('data-color-mode','dark')", null)
    }

    private fun select(i: Int) {
        cur = i; holder.removeAllViews(); holder.addView(tabs[i])
        addr.setText(tabs[i].url ?: ""); tabBtn.text = "▢ ${tabs.size}"
    }

    private fun closeTab() {
        if (tabs.size == 1) { load(g); return }
        val w = tabs.removeAt(cur); holder.removeAllViews(); w.destroy(); select(minOf(cur, tabs.size - 1))
    }

    private fun tabList() {
        val n = tabs.mapIndexed { i, w -> (if (i == cur) "● " else "○ ") + (w.title ?: w.url ?: "New tab") }
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK).setTitle("${tabs.size} tabs")
            .setItems(n.toTypedArray()) { _, i -> select(i) }
            .setPositiveButton("＋ New") { _, _ -> newTab(g) }
            .setNegativeButton("Close tab") { _, _ -> closeTab() }.show()
    }

    private fun go(q: String) {
        val s = q.trim()
        val u = when {
            s.isEmpty() -> return
            s.startsWith("http") -> s
            Regex("^[\\w-]+/[\\w.-]+$").matches(s) -> "$g/$s"
            s.contains(".") && !s.contains(" ") -> "https://$s"
            else -> "$g/search?q=" + Uri.encode(s)
        }
        load(u)
    }

    private fun load(u: String) {
        tab().loadUrl(u); addr.clearFocus(); tab().requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(addr.windowToken, 0)
    }

    private fun mi(t: String, f: () -> Unit) = Pair(t, f)

    private fun menu() {
        val u = tab().url ?: ""
        val items = listOf(
            mi("➕  New tab") { newTab(g) },
            mi(if (desktop) "📱  Mobile site" else "🖥  Desktop site") {
                desktop = !desktop
                tabs.forEach { it.settings.userAgentString = if (desktop) desk else null }
                tab().reload()
            },
            mi(if (darkGh) "☀️  Light GitHub" else "🌙  Dark GitHub") { darkGh = !darkGh; tab().reload() },
            mi("🔎  Find in page") { find() },
            mi("⭐  Bookmark this page") { add("bm", tab().title, u); toast("Bookmarked") },
            mi("📚  Bookmarks") { show("bm") },
            mi("🕘  History") { show("hist") },
            mi("⬇️  Download repo as ZIP") { repo()?.let { load("$it/archive/HEAD.zip") } },
            mi("⌨️  Open in github.dev") { load(u.replace("://github.com", "://github.dev")) },
            mi("📋  Copy git clone command") { repo()?.let { copy("git clone $it.git") } },
            mi("🔗  Copy link") { copy(u) },
            mi("📤  Share") {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, u), null))
            },
            mi("🧹  Clear cookies & cache") {
                CookieManager.getInstance().removeAllCookies(null); WebStorage.getInstance().deleteAllData()
                tab().clearCache(true); toast("Cleared")
            }
        )
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setItems(items.map { it.first }.toTypedArray()) { _, i -> items[i].second() }.show()
    }

    private fun find() {
        val e = EditText(this)
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK).setTitle("Find in page").setView(e)
            .setPositiveButton("Find") { _, _ -> tab().findAllAsync(e.text.toString()) }.show()
    }

    private fun repo(): String? {
        val p = Uri.parse(tab().url ?: "")
        val s = p.pathSegments
        if (p.host != "github.com" || s.size < 2) { toast("Open a repository first"); return null }
        return "$g/${s[0]}/${s[1]}"
    }

    private fun copy(s: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("url", s))
        toast("Copied")
    }

    private fun list(k: String) = (prefs.getString(k, "") ?: "").split("\n").filter { it.contains("\t") }

    private fun add(k: String, t: String?, u: String?) {
        if (u.isNullOrEmpty()) return
        val e = (t ?: u).replace(Regex("[\t\n]"), " ") + "\t" + u
        val all = listOf(e) + list(k).filter { !it.endsWith("\t$u") }
        prefs.edit().putString(k, all.take(100).joinToString("\n")).apply()
    }

    private fun show(k: String) {
        val l = list(k)
        if (l.isEmpty()) { toast("Nothing here yet"); return }
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle(if (k == "bm") "Bookmarks" else "History")
            .setItems(l.map { it.substringBefore("\t") }.toTypedArray()) { _, i -> load(l[i].substringAfter("\t")) }.show()
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); i.data?.let { newTab(it.toString()) } }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        picker?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c, d)); picker = null
    }

    override fun onBackPressed() {
        if (tab().canGoBack()) tab().goBack() else if (tabs.size > 1) closeTab() else super.onBackPressed()
    }
}
